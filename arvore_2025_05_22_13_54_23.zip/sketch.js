let temperatura = 20;
let farmerEmoji = '🧑‍🌾';
let trees = [];
let lastPlantTime = 0;
let plantDelay = 500;
let temperaturaBasePorArvore = 0.05;
let variacaoTemperatura = 0.03;
let numArvoresPlantadas = 0;
let influenciaDensidade = 0.01;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(220);

  textSize(16);
  fill(100);
  text(`Temperatura: ${temperatura.toFixed(1)}°C`, 20, 30);
  text(`Árvores Plantadas: ${numArvoresPlantadas}`, 20, 50);

  // Simula a mudança natural de temperatura
  if (frameCount % 180 === 0) {
    let change = random(-0.3, 0.7);
    temperatura += change;
    temperatura = constrain(temperatura, -5, 35);
  }

  // Desenha as árvores plantadas e recalcula a temperatura
  temperatura = 20; // Resetando a temperatura base a cada frame para recalcular o efeito das árvores
  for (let i = 0; i < trees.length; i++) {
    drawTree(trees[i].x, trees[i].y);
    let reducao = temperaturaBasePorArvore + random(-variacaoTemperatura, variacaoTemperatura);
    temperatura -= reducao;

    // Calcula a influência da densidade
    for (let j = 0; j < trees.length; j++) {
      if (i !== j) {
        let distancia = dist(trees[i].x, trees[i].y, trees[j].x, trees[j].y);
        if (distancia < 50) {
          temperatura -= influenciaDensidade;
        }
      }
    }
    temperatura = constrain(temperatura, -5, 35);
  }

  // Desenha o fazendeiro
  textSize(48);
  text(farmerEmoji, 50, height - 50);
}

function drawTree(x, y) {
  fill(139, 69, 19);
  rect(x - 10, y - 40, 20, 40);

  fill(34, 139, 34);
  ellipse(x, y - 50, 40, 30);
}

function mouseClicked() {
  if (mouseButton === LEFT) {
    if (millis() - lastPlantTime > plantDelay) {
      trees.push({ x: mouseX, y: mouseY });
      lastPlantTime = millis();
      numArvoresPlantadas++;
    }
  } else if (mouseButton === RIGHT) {
    let closestTreeIndex = -1;
    let closestDistance = Infinity;
    for (let i = 0; i < trees.length; i++) {
      let distancia = dist(mouseX, mouseY, trees[i].x, trees[i].y);
      if (distancia < closestDistance) {
        closestDistance = distancia;
        closestTreeIndex = i;
      }
    }
    if (closestTreeIndex !== -1) {
      trees.splice(closestTreeIndex, 1);
      numArvoresPlantadas--;
      if (numArvoresPlantadas < 0) numArvoresPlantadas = 0;
    }
  }
}

function mousePressed() {
  if (mouseButton === RIGHT) {
    return false;
  }
  return true;
}